#!/bin/sh

get_cpu_info()
{
	CPU_FILE=./dpi_cpu_cfg.ini

	percores=`lscpu | grep "Core(s) per socket" | awk -F" " '{print $4}'`
	#cpunum=`lscpu | grep "NUMA node(s)" | awk -F" " '{print $3}'`
	cpunum=`numactl --hardware | grep available: | awk -F" " '{print $2}'`
	sed -i "/^cpu_num/d" $CPU_FILE
	grep -s "^cpu_num" $CPU_FILE > /dev/null
	if [ $? -ne 0 ];then
        echo "cpu_num=$cpunum;" >> $CPU_FILE
	fi
	for ((i=0;i<$cpunum;i++))
	do
				sed -i "/^cpu$i/d" $CPU_FILE
        grep -s "^cpu$i" $CPU_FILE > /dev/null
        if [ $? -eq 0 ];then
            continue
        fi
#       cpuinfo=`lscpu | grep "NUMA node$i" | awk -F" " '{print $4}'`
        cpuinfo=`numactl --hardware | grep "node $i cpus" | awk -F": " '{print $2}'`
        OLD_IFS="$IFS"
        IFS=" "
        arr=($cpuinfo)
        IFS="$OLD_IFS"
        
        echo -n "cpu$i=" >> $CPU_FILE
        for ((j=0;j<$percores;j++))
        do
            if [ $j -eq 0 ];then
                echo -n "${arr[$percores-$j-1]}" >> $CPU_FILE
            else
                echo -n " ${arr[$percores-$j-1]}" >> $CPU_FILE
            fi
        done
        echo ";" >> $CPU_FILE
	done
}

install_ver()
{
	echo  "Create dir /home/log..."
	mkdir -p /home/log
	echo  "Install bins & run libs"
	rm -rf /home/icrs
	ln -s `pwd`/bin /home/icrs
	chmod +x /home/icrs/*
	chmod +x /home/icrs/tools/*
	pathcnt=`grep "/home/icrs:" /etc/profile | wc -l`
	if [ $pathcnt -lt 1 ];then
		echo  "export PATH=\"/home/icrs:\$PATH\"" >> /etc/profile
	fi
	pathcnt=`grep "ICRS_HOME" /etc/profile | wc -l`
	if [ $pathcnt -lt 1 ];then
		echo  "export ICRS_HOME=\"/home/icrs\"" >> /etc/profile
	fi
	pathcnt=`grep "ICRS_TOOLS" /etc/profile | wc -l`
	if [ $pathcnt -lt 1 ];then
		echo  "export ICRS_TOOLS=\"/home/icrs/tools\"" >> /etc/profile
	fi
	source /etc/profile
	#	$(shell source /etc/profile)
	libcnt=`grep "/home/icrs" /etc/ld.so.conf | wc -l`
	if [ $libcnt -lt 1 ];then
		echo  "/home/icrs" >> /etc/ld.so.conf
	fi
	ldconfig
	echo "Install shell conf files..."
	\cp -rf ./bin/conf /usr/local/bin/
	#	echo -n "Install dpi config files..."
	#	\cp -f ./bin/dpi_cpu_cfg.ini /usr/local/bin/
	#	\cp -f ./bin/dpi.xml /usr/local/bin/
	#	echo -n "Install shell libs..."
	#	\cp -f ./bin/libvst_com.so /usr/local/bin/
	#	\cp -f ./bin/libvst_memory.so /usr/local/bin/
	#	\cp -f ./bin/libvst_plat.so /usr/local/bin/
	#	\cp -f ./bin/libvst_encrypt.so /usr/local/bin/
	#	\cp -f ./bin/libbase_log.so /usr/local/bin/
	#	\cp -f ./bin/libvst_shell_cli.so /usr/local/bin/
	#	\cp -f ./bin/libvst_shell_log.so /usr/local/bin/
	#	\cp -f ./bin/vst_shell /usr/local/bin/
	cd bin
	if [ ! -s libmxml.so ]; then
		ln -s libmxml.so.1 libmxml.so
	fi
	
	if [ ! -s libmysqlclient.so.18.1.0 ]; then
		ln -s libmysqlclient.so libmysqlclient.so.18.1.0
	fi
	
	if [ ! -s libmysqlclient.so.18 ]; then
		ln -s libmysqlclient.so libmysqlclient.so.18
	fi	
	
	if [ ! -s libmysqlclient_r.so.18.1.0 ]; then
		ln -s libmysqlclient.so libmysqlclient_r.so.18.1.0
	fi
	
	if [ ! -s libmysqlclient_r.so.18 ]; then
		ln -s libmysqlclient.so libmysqlclient_r.so.18
	fi		
	
	if [ ! -s libmysqlclient_r.so ]; then
		ln -s libmysqlclient.so libmysqlclient_r.so
	fi

	get_cpu_info
	cd ..
	
	memorycnt=`grep "^vm.overcommit_ratio" /etc/sysctl.conf | wc -l`
	if [ $memorycnt -lt 1 ];then
		echo  "vm.overcommit_ratio=90" >> /etc/sysctl.conf
	fi
	memorycnt=`grep "^vm.overcommit_memory" /etc/sysctl.conf | wc -l`
	if [ $memorycnt -lt 1 ];then
		echo  "vm.overcommit_memory=2" >> /etc/sysctl.conf
	fi
	sysctl -p
#	sysctl -w vm.overcommit_memory=2
#	sysctl -w vm.overcommit_ratio=90
	echo "Install Linux version successful..."
	echo -e "\033[42m Type \"source /etc/profile\" to use latest Environment \033[0m"
	return 0
}

install_webver()
{
#	echo  "Add htaccess file..."
#	touch /usr/local/apache2/htdocs/.htaccess
#	chmod 777 /usr/local/apache2/htdocs/.htaccess
	echo -n "Please backup config files manually,Continue?(Y/N)"
	read yesno
	if [ "$yesno"x != "Y"x ];then
		return
	fi
	echo  "Install icrs web content..."
	\cp -rf /usr/local/apache2/htdocs/icrs/resource/licfiles ./
	echo "Cleaning apache cache..."
	rm -rf /usr/local/apache2/htdocs/icrs/*
	\cp -rf ./monitor/icrs /usr/local/apache2/htdocs/
	\cp -rf ./licfiles/* /usr/local/apache2/htdocs/icrs/resource/licfiles/
	rm -rf ./licfiles
	echo "Install oam config template..."
	\cp -f ./bin/ndap_oam_config.csv /usr/local/apache2/htdocs/icrs/resource/
	chmod 777 -R /usr/local/apache2/htdocs/icrs/resource
	chmod 777 -R /usr/local/apache2/htdocs/icrs/Runtime
	echo  "Install tomcat web content..."
	mkdir -p /usr/local/tomcat/webapps/icrs
	echo "Cleaning tomcat cache..."
	rm -rf /usr/local/tomcat/webapps/icrs/*
	rm -rf /usr/local/tomcat/webapps/iPearl/*
	\cp -rf ./monitor/tomcat/icrs/WebRoot/* /usr/local/tomcat/webapps/icrs/
	mkdir -p /usr/local/tomcat/webapps/iPearl
	\cp -rf ./monitor/tomcat/iPearl/WebRoot/* /usr/local/tomcat/webapps/iPearl/
	echo  "Install web successful..."
}

install_oam()
{
	 cd nmsbin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on NMSP  ***************"
	  echo "                                                                   "
	  echo "   1  -  Install Keep on NMSP                                      "
	  echo "   2  -  Uninstall Keep on NMSP                                    "
	  echo "   0  -  Exit                                                      "
	  echo "-------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_nmsp.sh
	  	 if [ $? -eq 0 ]; then
	  	 		echo "Install Keep on NMSP successful..." 
	  	 else
	  	 		echo "Install Keep on NMSP failed..." 
	  	 fi
	    ;;
	  2)  ./uninstall_keep_nmsp.sh
	  		echo "Uninstall Keep on NMSP successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 
	 cd ../..

	 return 0
}

install_scm()
{
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on SCM  ***************"
	  echo "                                                                  "
	  echo "   1  -  Install Keep on SCM                                      "
	  echo "   2  -  Uninstall Keep on SCM                                    "
	  echo "   0  -  Exit                                                     "
	  echo "------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_scmk.sh
	 			echo "Install Keep on SCM successful..."  
	    ;;
	  2)  ./uninstall_keep_scmk.sh 
	  		echo "Uninstall Keep on SCM successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
	 return 0
}

install_logCheck()
{
	 cd bin/crontab
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on logCheck  **********"
	  echo "                                                                  "
	  echo "   1  -  Install Keep on logCheck                                 "
	  echo "   2  -  Uninstall Keep on logCheck                               "
	  echo "   0  -  Exit                                                     "
	  echo "------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  sh add_crontab.sh
	 			echo "Install Keep on logCheck successful..."  
	    ;;
	  2)  sh del_crontab.sh 
	  		echo "Uninstall Keep on logCheck successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
	 return 0
}

install_mysql()
{
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on Mysql  ***************"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on Mysql                                      "
	  echo "   2  -  Uninstall Keep on Mysql                                    "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_mysql.sh
	  	 echo "Install Keep on Mysql successful..."  
	    ;;
	  2)  ./uninstall_keep_mysql.sh
	  	echo "Uninstall Keep on Mysql successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_oracle()
{
	 sed -i "s/:N/:Y/" /etc/oratab
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on Oracle  ***************"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on Oracle                                     "
	  echo "   2  -  Uninstall Keep on Oracle                                   "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_oracle.sh
	  	 echo "Install Keep on Oracle successful..."  
	    ;;
	  2)  ./uninstall_keep_oracle.sh
	  	echo "Uninstall Keep on Oracle successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_apache()
{
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on Apache ***************"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on Apache                                     "
	  echo "   2  -  Uninstall Keep on Apache                                   "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_apache.sh
	  	 echo "Install Keep on Apache successful..."  
	    ;;
	  2)  ./uninstall_keep_apache.sh
	  	echo "Uninstall Keep on Apache successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_mongo()
{
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on Mongo  ***************"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on Mongo                                      "
	  echo "   2  -  Uninstall Keep on Mongo                                    "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_mongo.sh
	  	 echo "Install Keep on Mongo successful..."  
	    ;;
	  2)  ./uninstall_keep_mongo.sh
	  	echo "Uninstall Keep on Mongo successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_tomcat()
{
	 cd bin/keep
	 
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on Tomcat  ***************"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on Tomcat                                     "
	  echo "   2  -  Uninstall Keep on Tomcat                                   "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  ./install_keep_tomcat.sh
	  	 echo "Install Keep on Tomcat successful..."  
	    ;;
	  2)  ./uninstall_keep_tomcat.sh
	  	echo "Uninstall Keep on Tomcat successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

init_driver()
{
	if [ ! -f /lib/modules/$(uname -r)/kernel/drivers/uio/uio.ko ] ; then
		echo "No uio module found"
		return
	fi

	echo "Init numa memory..."
	echo > .echo_tmp
    for d in /sys/devices/system/node/node? ; do
        node=$(basename $d)
        echo -n "Please input number of pages for $node: "
        read Pages
        if [ X"$Pages" ==  X ];then
                Pages=0
        fi
        echo "echo $Pages > $d/hugepages/hugepages-2048kB/nr_hugepages" >> .echo_tmp
    done
	sed -i "/^echo/d" ./drv_install.sh
	sed -i "/#hugepages/r .echo_tmp" ./drv_install.sh
	rm -f .echo_tmp
	echo "Init numa memory...ok"
	./drv_install.sh
	echo "Set driver auto-loading..."
#	grep -s '^/home/icrs/tools/drv_install.sh' /etc/rc.local > /dev/null
#	if [ $? -ne 0 ];then
#		echo "/home/icrs/tools/drv_install.sh" >> /etc/rc.local
#		chmod +x /etc/rc.d/rc.local
#	fi
	sed -i -c "/drv_install.sh/d" /etc/rc.local
	echo "/home/icrs/tools/drv_install.sh" >> /etc/rc.local
	chmod +x /etc/rc.d/rc.local
	echo "Set driver auto-loading...ok"
}

uninit_driver()
{
	echo "Unset driver auto-loading..."
	grep -s 'drv_install.sh' /etc/rc.local > /dev/null
	if [ $? -eq 0 ];then
		sed -i -c "/drv_install.sh/d" /etc/rc.local
#		chmod +x /etc/rc.d/rc.local
	fi
	echo "Unset driver auto-loading...ok"
}

install_driver()
{
	 cd bin/tools
	 chmod +x *.sh
	 chmod +x *.py
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Driver   *********************"
	  echo "                                                                    "
	  echo "   1  -  Install Driver                                             "
	  echo "   2  -  Uninstall Driver                                           "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  init_driver
		echo "Install Driver successful..."  
	    ;;
	  2)  uninit_driver
	  	echo "Uninstall Driver successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

init_nic()
{
	while true
	do
		echo > .tmp_nic
		echo -n "Please input nic name,0(end):"
		read nic
		if [ "$nic"x = "0"x ];then
			break
		fi
		echo "ifconfig $nic down" >> .tmp_nic
		echo "./igb_uio_bind.py --bind=igb_uio $nic" >> .tmp_nic
		grep -s "$nic" ./nic_bind.sh > /dev/null
		if [ $? -ne 0 ];then
			sed -i "/#nicbind/r .tmp_nic" ./nic_bind.sh
		fi
#	ifconfig eno3 | grep ether | tr -s ' ' | cut -d ' ' -f3
		nicmac=`ifconfig $nic | grep ether | awk -F" " '{print $2}'`
		nicpci=`ethtool -i $nic | grep bus-info | awk -F" " '{print $2}'`
		grep -s "$nicmac" /home/icrs/dpi_cpu_cfg.ini > /dev/null
		if [ $? -ne 0 ];then
			sed -i "/#info/a $nicmac=$nicpci;" /home/icrs/dpi_cpu_cfg.ini
		fi
	done
	if [ -s ".tmp_nic" ];then
		./nic_bind.sh
	fi
	rm -f .tmp_nic
	echo "Set nic binding auto-loading..."
#	grep -s '^/home/icrs/tools/nic_bind.sh' /etc/rc.local > /dev/null
#	if [ $? -ne 0 ];then
#		echo "/home/icrs/tools/nic_bind.sh" >> /etc/rc.local
#		chmod +x /etc/rc.d/rc.local
#	fi
	sed -i -c "/nic_bind.sh/d" /etc/rc.local
	echo "/home/icrs/tools/nic_bind.sh" >> /etc/rc.local
	chmod +x /etc/rc.d/rc.local
	echo "Set nic binding auto-loading...ok"
}

uninit_nic()
{
    echo "Unset nic bind auto loading..."
    grep -s 'nic_bind.sh' /etc/rc.local > /dev/null
		if [ $? -eq 0 ];then
			sed -i -c "/nic_bind.sh/d" /etc/rc.local
#			chmod +x /etc/rc.d/rc.local
		fi
		echo "Unset nic bind auto loading...ok"
}

install_nic()
{
#	get nic mac
#	ifconfig eno3 | grep ether | tr -s ' ' | cut -d ' ' -f3
#	ifconfig eno3 | grep ether | awk -F" " '{print $2}'
	 cd bin/tools
	 chmod +x *.sh
	 chmod +x *.py
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall NICS   ***********************"
	  echo "                                                                    "
	  echo "   1  -  Install NICS                                               "
#	  echo "   2  -  Uninstall NICS                                             "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  init_nic
		echo "Install NICS successful..."  
	    ;;
#	  2)  uninit_nic
#	  	echo "Uninstall NICS successful..."  
#	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_ndap_file()
{
	 cd bin/keep
	 chmod +x *.sh
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Keep on NDAP File Mount *******"
	  echo "                                                                    "
	  echo "   1  -  Install Keep on NDAP File Mount                            "
	  echo "   2  -  Uninstall Keep on NDAP File                                "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  echo -n "Is the config of file '/home/icrs/bin/keep/fs_check.cfg' ok?(Y/N)"
		read yesno
		if [ "$yesno"x != "Y"x ];then
			break
		fi
		./install_fs_check.sh
		echo "Install Keep on NDAP File Mount successful..."  
	    ;;
	  2)  ./uninstall_fs_check.sh
	  echo "Uninstall Keep on NDAP File Mount successful..."  
	  	;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

uninstall_core()
{
    echo "Unsetting Coredump..."
    grep -s 'core_gen.sh' /etc/rc.local > /dev/null
		if [ $? -eq 0 ];then
			sed -i -c "/core_gen.sh/d" /etc/rc.local
#			chmod +x /etc/rc.d/rc.local
		fi
		grep -s '^ulimit -c unlimited' /etc/profile > /dev/null
		if [ $? -eq 0 ];then
			sed -i "/^ulimit -c unlimited/d" /etc/profile
		fi
		echo "Unsetting Coredump...ok"
}

install_core()
{
		echo "Setting Coredump..."
		./core_gen.sh
		grep -s '^/home/icrs/tools/core_gen.sh' /etc/rc.local > /dev/null
		if [ $? -ne 0 ];then
			echo "/home/icrs/tools/core_gen.sh" >> /etc/rc.local
			chmod +x /etc/rc.d/rc.local
		fi
		grep -s '^ulimit -c unlimited' /etc/profile > /dev/null
		if [ $? -ne 0 ];then
			echo "ulimit -c unlimited" >> /etc/profile
		fi
		echo "Setting Coredump...ok"
}

install_cpu_core()
{
	echo "Install cpu core..."
	grubfile=`find /boot/ -name "grub.cfg"`
	if [ "$grubfile"Y == Y ];then
		echo "cannot find system grub file"
		return
	fi
	grep -s 'isolcpus' $grubfile > /dev/null
	if [ $? -eq 0 ];then
		echo "found cpu setting,please unistall first"
		return
	fi
	bdell=`dmidecode | grep "Product Name" | grep "PowerEdge" | wc -l`
	bhp=`dmidecode | grep "Product Name" | grep "ProLiant" | wc -l`
	if [ $bdell -ge 1 ];then
		sed -i -c "/.linux16/{s/$/\ isolcpus=8,10,20,22 /}" $grubfile
		sed -i -c "/.linuxefi/{s/$/\ isolcpus=8,10,20,22 /}" $grubfile
	elif [ $bhp -ge 1 ];then
		sed -i -c "/.linux16/{s/$/\ isolcpus=4,5,16,17 /}" $grubfile
		sed -i -c "/.linuxefi/{s/$/\ isolcpus=4,5,16,17 /}" $grubfile
	else
		echo "cannot find machine type use dmidecode"
		return
	fi
	echo "Install cpu core...ok"
}

uninstall_cpu_core()
{
	grubfile=`find /boot/ -name "grub.cfg"`
	if [ "$grubfile"Y == Y ];then
		echo "cannot find system grub file"
		return
	fi
	grep -s 'isolcpus' $grubfile > /dev/null
	if [ $? -ne 0 ];then
		echo "no isolcpus found,please install first"
		return
	fi
	bdell=`dmidecode | grep "Product Name" | grep "PowerEdge" | wc -l`
	bhp=`dmidecode | grep "Product Name" | grep "ProLiant" | wc -l`
	if [ $bdell -ge 1 ];then
		sed -i -c "/.linux16/{s/\ isolcpus=8,10,20,22 //}" $grubfile
		sed -i -c "/.linuxefi/{s/\ isolcpus=8,10,20,22 //}" $grubfile
	elif [ $bhp -ge 1 ];then
		sed -i -c "/.linux16/{s/\ isolcpus=4,5,16,17 //}" $grubfile
		sed -i -c "/.linuxefi/{s/\ isolcpus=4,5,16,17 //}" $grubfile
	else
		echo "cannot find machine type use dmidecode"
		return
	fi
}

install_cpucore()
{
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Coredump Settings  ***********"
	  echo "                                                                    "
	  echo "   1  -  Install CPU Core                                           "
	  echo "   2  -  Uninstall CPU Core                                         "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  install_cpu_core
	  	 echo "Install cpu core successful..."  
	    ;;
	  2)  uninstall_cpu_core
	  	echo "Uninstall cpu core successful..."  
	    ;;
	  0)   break
	    ;; 
	  esac
	 done
}

install_coredump()
{
	 cd bin/tools
	 chmod +x *.sh
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Install/Uninstall Coredump Settings  ***********"
	  echo "                                                                    "
	  echo "   1  -  Install Coredump                                           "
	  echo "   2  -  Uninstall Coredump                                         "
	  echo "   0  -  Exit                                                       "
	  echo "--------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)  install_core
	  	 echo "Install Coredump setting successful..."  
	    ;;
	  2)  uninstall_core
	  	echo "Uninstall Coredump setting successful..."  
	    ;;  
	  0)   break
	    ;; 
	  esac
	 done
	 
	 cd ../..
}

install_version()
{
	 #installation options
	 while true 
	 do
	  echo ""
	  echo ""
	  echo "*****************   Version Installation  *************************"
	  echo "                                                                   "
	  echo "   1  -  Install Linux version                                     "
	  echo "   2  -  Install Web version                                       "
	  echo "   3  -  Install/Uninstall Keep on NMSP                            "
	  echo "   4  -  Install/Uninstall Keep on SCM                             "
	  echo "   5  -  Install/Uninstall Keep on MYSQL                           "
	  echo "   6  -  Install/Uninstall Keep on APACHE                          "
	  echo "   7  -  Install/Uninstall Keep on MONGO                           "
	  echo "   8  -  Install/Uninstall Keep on TOMCAT                          "
	  echo "   9  -  Install/Uninstall Keep on NDAP File Mount                 "
	  echo "   10 -  Install/Uninstall Driver                                  "
	  echo "   11 -  Install/Uninstall NICS                                    "
	  echo "   12 -  Install/Uninstall CPU Core Settings                       "
	  echo "   13 -  Install/Uninstall Coredump Settings                       "
    echo "   14 -  Install/Uninstall Log Check                               "
	  echo "   0  -  Exit                                                      "
	  echo "-------------------------------------------------------------------"
	  echo -n "Please Choose: "
	  read ch
	  case $ch in
	  1)    install_ver
	    ;;
	  2)    install_webver
	    ;;
	  3)    install_oam
	    ;;
	  4)    install_scm
	    ;;
	  5)    install_mysql
	    ;;	
	  6)    install_apache
	    ;;
	  7)    install_mongo
	    ;;	
	  8)    install_tomcat
	    ;;
	  9)    install_ndap_file
	    ;;
	  10)   install_driver
	    ;;
	  11)   install_nic
	    ;;
		12)	  install_cpucore
	  	;;
	  13)	  install_coredump
	  	;;
	  14)	  install_logCheck
	  	;;
	  0)   break
	    ;; 
	  esac
	 done
	 
	 return 0
}
 
#main
usr=`whoami | grep root | wc -l`
if [ $usr -eq 0 ]
then
 echo "Please run this script as root"
 exit 1
fi

chmod +x bin/*.sh 2 &> /dev/null
chmod +x bin/keep/*.sh 2 &> /dev/null
chmod +x nmsbin/keep/*.sh 2 &> /dev/null
install_version
echo "Bye!"
