#!/bin/bash
#This script update svn code and complie, then update the result to ftp version dir.

#共支持3种方式:
#1）最新版本编译 sh make_CRS_3.9_C_version.sh auto
#2）指定统一版本号编译 sh make_CRS_3.9_C_version.sh XXXX
#3）指定每一个子系统版本号编译 sh make_CRS_3.9_C_version.sh

version=
projectver=
nmsconfigfile=
timedata=
username=whl
password=hengliang123
svnunione=https://172.168.1.113/svn/UNIONE/
svnproject=https://172.168.1.113/svn/project/
analysisdir=analysis/v1.5.01/code/c_platform
basedir=base/v1.7/code/c_platform
msdir=ms/v1.6/code
nmsdir=nms/v1.3/code
protocoldir=protocol/v1.7/code
storagedir=storage/v1.5.01/code/c_platform

input_version()
{
	read -p "input $1 version:" version
	if [ -z $version ];then
		version=`svn info ${svnunione}$1 --username=${username} --password=${password} | grep "Revision:"|awk '{print $2}'`
	fi
	echo $1 version $version >> out.txt 
	return 0
}

#first, clean dir by time
timedata=$(date +%Y%m%d)
echo timedata is $timedata
sudo rm -rf $timedata
echo delete $timedata
mkdir $timedata
cd $timedata
echo complie time $(date +%Y%m%d%T) >> out.txt

#second, get code from svn by specified version
if [ $# -eq 1 ];then
  if [ $1 != auto ];then
    version=$1
  else
    version=`svn info ${svnunione} --username=${username} --password=${password} | grep "Revision:"|awk '{print $2}'`
  fi
  echo $svnunione complie version $version >> out.txt

  svn co ${svnunione}$analysisdir ./$analysisdir --username=$username --password=$password -r $version
  svn co ${svnunione}$basedir ./$basedir --username=$username --password=$password -r $version
  svn co ${svnunione}$msdir ./$msdir --username=$username --password=$password -r $version
  svn co ${svnunione}$nmsdir ./$nmsdir --username=$username --password=$password -r $version
  svn co ${svnunione}$protocoldir ./$protocoldir --username=$username --password=$password -r $version
  svn co ${svnunione}$storagedir ./$storagedir --username=$username --password=$password -r $version
  echo $svnunione update suc. >> out.txt
else
  input_version $analysisdir
  analysis_version=$version
  input_version $basedir
  base_version=$version
  input_version $msdir
  ms_version=$version
  input_version $nmsdir
  nms_version=$version
  input_version $protocoldir
  proto_version=$version
  input_version $storagedir
  storage_version=$version
  
  svn co ${svnunione}$analysisdir ./$analysisdir --username=$username --password=$password -r $analysis_version
  svn co ${svnunione}$basedir ./$basedir --username=$username --password=$password -r $base_version
  svn co ${svnunione}$msdir ./$msdir --username=$username --password=$password -r $ms_version
  svn co ${svnunione}$nmsdir ./$nmsdir --username=$username --password=$password -r $nms_version
  svn co ${svnunione}$protocoldir ./$protocoldir --username=$username --password=$password -r $proto_version
  svn co ${svnunione}$storagedir ./$storagedir --username=$username --password=$password -r $storage_version
  echo $svnunione update suc. >> out.txt
  
fi


mkdir nmsconfigfile
nmsconfigfile=`svn co ${svnproject}iPearl/v3.0/9\ 子版本管理/ ./nmsconfigfile --username=$username --password=$password | grep "Checked out revision" | awk '{print $4}'`
echo $svnproject $nmsconfigfile nms config file >> out.txt
cp -f nmsconfigfile/ndap_oam_config.csv ./

projectver=`svn co ${svnproject}CRS/V3.9/7\ 子版本管理/ ./ --username=$username --password=$password | grep "Checked out revision" | awk '{print $4}'`
echo $svnproject $projectver project file >> out.txt


#third, complie the code by makefile
make -f makefile_CRS3.9 LINUX_X86=Y DEBUG=Y
echo make complie suc. >> out.txt
#forth, compress output dir and update to ftp
tar -zcvf CRS_v3.9_C_${timedata}_${version}.tar.gz ./output
echo final output CRS_v3.9_C_${timedata}_${version}.tar.gz >> out.txt
